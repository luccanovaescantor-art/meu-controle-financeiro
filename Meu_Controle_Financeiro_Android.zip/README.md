# Meu Controle Financeiro — versão 4.70

## v4.70 — Refinamento final do cadastro
- Listas de tipo de ativo, nome do ativo, instituição/corretora e demais seletores mantidas na implementação única já funcional.
- Listas continuam roláveis e selecionáveis com um único toque, fechando imediatamente após a escolha.
- Menus agora respeitam uma margem segura de 22px nas bordas superior e inferior da tela, sem encostar no teto ou no rodapé do celular.
- O menu continua visualmente colado ao campo de origem, com espaçamento curto e altura limitada para manter a rolagem natural.
- Após selecionar o tipo de ativo, o foco segue primeiro para “Nome do ativo”; após selecionar o ativo, segue para “Instituição / corretora”; após selecionar a instituição, segue para o próximo campo necessário.
- Ao selecionar o nome do ativo, a sugestão não navega para o dashboard e o menu é encerrado corretamente.
- Com teclado aberto, a barra inferior do aplicativo fica totalmente fora da área visível, inclusive o botão flutuante, eliminando qualquer recorte sobre o botão “Salvar investimento”.
- Com teclado aberto ou fechado, o limite final de rolagem do cadastro deixa o botão “Salvar investimento” como último conteúdo visível, sem faixa preta adicional abaixo.
- Mantida a consulta automática de cotação para ativos negociados por quantidade e o preenchimento automático de preço/valor quando houver cotação disponível.

## v4.69 — Cadastro de investimentos: listas e teclado
- Cadastro mantido como página completa, sem formulário em modal.
- Implementação única do fluxo de listas de tipo, ativo, instituição e demais seletores, sem empilhamento de correções no cadastro.
- Todas as listas são roláveis e aceitam seleção em um único toque; ao selecionar, fecham imediatamente.
- Enquanto uma lista estiver aberta, a página de cadastro fica sem receber gestos; somente a lista pode rolar/receber toque.
- Com teclado aberto, listas abrem para cima e mantêm margem visual do topo da tela; com teclado fechado, abrem para baixo quando houver espaço.
- Seleção do ativo avança para instituição/corretora; seleção da instituição avança para quantidade/valor.
- No cadastro de ativos negociados, preço e valor investido são preenchidos por cotação em tempo real (B3 via brapi.dev; cripto via Binance).
- Quando o teclado está aberto, a rolagem do cadastro termina exatamente no botão “Salvar investimento”, sem espaço preto, brilho do botão inferior ou conteúdo abaixo dele.
- Navegação inferior permanece fora da área visível/interativa enquanto o teclado estiver aberto.

## v4.67 — Cadastro de investimentos
- Mantida uma única tela real de cadastro, sem card/modal Android para o formulário.
- Seletores e sugestões usam componentes HTML do próprio aplicativo.
- Ao abrir uma lista, a página de cadastro fica sem interação de toque; somente a lista recebe o gesto.
- Listas aceitam rolagem sem selecionar um item acidentalmente durante o arraste.
- Com teclado aberto, listas e sugestões são posicionadas acima do teclado; sem teclado, podem abrir abaixo do campo.
- O menu de instituição/corretora apresenta sugestões também ao receber foco.
- A navegação inferior permanece fixa e fica fora da área de toque enquanto o teclado está aberto; a rolagem do cadastro termina no botão “Salvar investimento”.
- Removido o texto explicativo que ficava imediatamente acima do botão de salvar.
- Para ativos negociados por quantidade, a cotação pública é consultada no cadastro e, quando o usuário não informou preço médio/valor investido, o aplicativo calcula automaticamente esses valores pela cotação disponível.
- A atualização posterior do mercado continua preservando os dados cadastrados.


## v4.35 — Cadastro: rolagem e adaptação ao teclado

Nesta versão, os menus finais de Tipo de ativo e Nome/código do ativo foram ajustados para rolagem vertical nativa no Android e posicionamento dinâmico acima/abaixo do campo conforme o espaço disponível e o teclado virtual.

## v4.33 — Cadastro de investimentos reconstruído
- Seletor de tipo de ativo com estado único, seleção persistente e fechamento imediato após escolha.
- Lista de classes rolável e sem reabertura automática após a seleção.
- Autocomplete de ativos filtrado pela classe escolhida.
- Seleção do ativo fecha as sugestões sem alterar a classe.
- Qualquer edição posterior do nome/código invalida a seleção anterior e reabre as sugestões imediatamente.
- Removidas as camadas duplicadas de correções dos seletores/autocomplete, mantendo uma única implementação para esses controles.
# Meu Controle Financeiro — versão 4.33

Projeto Android/WebView do aplicativo **Meu Controle Financeiro**.

## Principais correções desta versão

## Rodada 6 — evolução da carteira
- Campo de busca da evolução não se autopreenche nem restaura texto antigo ao reabrir a tela.
- Cards das quatro classes da carteira (Renda Fixa, Renda Variável, Criptomoedas e Outros) são totalmente clicáveis e abrem uma página da classe com seus investimentos.
- Sugestões da busca desaparecem imediatamente após a seleção e nunca permanecem sobre outras telas/modais.
- Resultados da busca são vinculados ao conteúdo atual do campo: ao apagar a pesquisa, os resultados somem; ao sair da tela, a busca é zerada.
- Cada investimento da página da classe é apresentado em card próprio e clicável para abrir seus detalhes.


## Rodada 5 — cadastro, proventos e evolução
- Corrigida a obtenção automática de cotação para ativos B3, com fallback específico para FIIs.
- Removida a seção de vendas do cadastro de investimentos.
- Reativado o autocomplete por tipo de ativo, com sugestões clicáveis e ocultação após seleção.
- Proventos históricos anteriores ao cadastro deixam de ser exibidos/recuperados.
- Evolução dos investimentos mantém busca por ativo e cards de classes clicáveis.
- Ícone externo do aplicativo reconstruído a partir da carteira PNG original, em fundo escuro, com margem segura para evitar recorte no launcher.
- Splash screen refeita com a carteira original descendo de cima para baixo e o nome subindo de baixo para cima, encontrando-se juntos na região central da tela, sem quadrados, cortes ou sobreposição; o nome termina logo abaixo da carteira.
- Dashboard com análise financeira gráfica ao tocar no resumo: pizza de pago/restante/pendente quando houver atraso, barras mensais e diárias, evolução anual e indicadores reais; gráficos e status são atualizados após cada pagamento.
- Dashboard com reordenação por arrastar e também controles de subir/descer como alternativa, com salvamento da ordem.
- Cards de dívida com vencimento na linha superior, espaçamento interno mais confortável e valor total sempre presente junto dos demais indicadores.
- Status das dívidas recalculado automaticamente pela parcela pendente: Em aberto em branco acima de 7 dias; Vencimento próximo em amarelo/laranja de 7 dias até a véspera; Vencida em vermelho após o vencimento; após o pagamento, o card avança imediatamente para a próxima parcela e recalcula o status.
- Botão “Ver todas” e demais cards com espaçamento visual consistente.
- Relatórios com espaçamento corrigido e visão de pagamentos dos últimos 7 dias na análise gráfica.
- Pagamentos como extrato cronológico; cada registro abre um comprovante focado em valor, dívida, parcela, data e horário.
- Formulários de nova dívida e edição preservam todos os campos ao abrir calendário ou seletor e não sobrescrevem histórico existente.
- Calendário personalizado funcional para seleção de datas.
- Aprender com 20 livros e 600 ensinamentos (30 por livro), distribuídos de forma variada por tema.
- Ensinamentos com títulos e textos individualizados por livro e por entrada, com uma única leitura contínua e sem blocos repetitivos de “contexto/exercício/reflexão”.
- Aba Livros preservada, com 30 ensinamentos individualizados dentro de cada obra.
- Ícones personalizados na área de Aprender e na navegação inferior, com os ícones inferiores levemente ampliados sem alterar o botão central.
- Backup completo em JSON, com salvar via seletor do Android e importação validada.
- Animação minimalista de quitação somente quando a última parcela é paga, com artefatos visuais na identidade verde do aplicativo.

## Build
Abra `controle_financeiro_android` no Android Studio e gere o APK normalmente.


## Versão 2.0 — leitura dos ensinamentos
- Audiobook por Text-to-Speech do Android/WebView.
- Escolha da voz em português entre as vozes disponíveis no aparelho.
- Vozes identificadas pelo sistema como femininas/masculinas são sinalizadas.
- Velocidade de 0,5x a 2,0x.
- Tom mais grave, normal ou mais agudo.
- Preferências de voz salvas no dispositivo.
- Reprodução com pausa, retorno e avanço por trechos.

## Ajustes finais — 2.0
- Dashboard principal: resumo das dívidas unificado em um único card, com gráfico de pizza predominante e indicadores laterais.
- “Minhas dívidas” na tela inicial limitada às duas obrigações mais próximas; “Ver todas” mantém somente dívidas não fixas.
- Custos fixos mensais: botão “Ver todos”, lista separada para edição/pagamento e gráfico de pizza com uma cor por custo e percentual de participação no total mensal.
- Análise financeira: total, pago, restante, quitado e pendente reunidos em um único card maior, com pizza predominante; demais gráficos mantidos abaixo.
- Todos os gráficos de barras receberam margem superior para que as barras nunca cubram os valores exibidos no topo.
- Relatórios: gráfico “Evolução dos últimos 6 meses” corrigido para representar proporcionalmente os pagamentos reais registrados, inclusive o mês atual, com margem superior e valores legíveis.
- Espaçamento dos cards de maior/menor mês e demais blocos de análise ajustado para evitar encaixes colados.
- Cards de configurações de voz e Dashboard padronizados com divisor interno e botão em largura completa, seguindo o padrão de Backup e dados.
- Sheets/modais podem ser fechados arrastando para baixo a partir de qualquer área do card, além do gesto pela barra superior.
- Barra do audiobook com altura e interação de arraste corrigidas para permitir busca no texto de forma mais confiável.
- Ensinamentos: cada entrada usa título, abertura e estrutura de resumo próprios, com variação de abordagem entre os 30 tópicos de cada livro e títulos protegidos contra duplicação entre obras.


Versão de correção: v3.0 — ajustes incrementais de navegação, modais, orçamento, metas, campos de valor e saudação.


Base desta entrega: v2.33 — correção incremental sobre a última versão funcional v2.31, preservando as funcionalidades existentes.


## v3.5 — Carteira: análise e dados de mercado
- Dashboard inicial da carteira foi separado da visão analítica completa.
- Clique em Por classe, Por ativo, Por setor e Por instituição abre uma tela própria com gráfico e detalhamento.
- Evolução do patrimônio usa histórico de snapshots para gráfico de linha.
- Clique no investimento abre detalhes do ativo antes da edição.
- Atualização de mercado integrada para cripto via Binance e B3 via brapi, com fallback Stooq.
- A brapi gratuita tem atraso aproximado de 30 minutos para ações; portanto o app não chama isso de tempo real.
- A atualização pode ser manual e também periódica enquanto o app estiver aberto.
- Atalhos/símbolos comuns como Petro4/Petrobras são normalizados para PETR4.

## Atualização incremental — Minha Carteira v4.0
- Removido o caminho redundante “Investimentos” do dashboard da carteira e mantido somente o fluxo centralizado pelo card principal, distribuições e evolução.
- Removido “Ver análise completa” do rodapé; permanece apenas “Atualizar mercado”, com animação de rotação durante a atualização.
- Atualização de mercado preserva os dados cadastrados e altera somente informações de mercado/proventos que possam ser obtidas das fontes públicas.
- Card principal da carteira usa cores fixas por natureza: Renda Fixa, Renda Variável, Criptomoedas e Outros; o neon externo acompanha o resultado geral positivo/negativo da carteira e pulsa continuamente.
- “Por classe”, “Por ativo”, “Por setor” e “Por instituição” passaram a ter conteúdos realmente diferentes: primeiro mostram seus respectivos grupos; ao tocar em um grupo, mostram os investimentos relacionados.
- Gráficos de distribuição passaram a usar donut funcional, com valores adaptáveis e formatação que evita sobreposição/quebra do texto central.
- “Evolução dos investimentos” foi separado da análise geral da carteira e usa barras mensais baseadas nos dados históricos disponíveis para cada ativo, sem barras ilustrativas repetidas.
- Quantidade deixou de ser obrigatória para classes em que o cadastro é por valor; quantidade continua obrigatória apenas para Ações, FIIs, ETFs e BDRs. Cripto, CDB, LCI, LCA, Tesouro e Outros trabalham por valor aplicado e calculam frações quando houver cotação histórica disponível.
- Compra e venda usam calendário próprio do aplicativo, com seleção de data e horário em layout escuro padronizado, sem abrir o seletor nativo quebrado do Android.
- O seletor de classe é totalmente clicável, mantém a seleção em verde e, ao ser fechado por gesto, retorna diretamente ao formulário de cadastro do ativo.
- Proventos/rendimentos de ações e FIIs são buscados quando disponíveis nas fontes públicas e incorporados sem apagar lançamentos existentes.
- As áreas “Detalhamento” e “Investimentos relacionados” são independentes e roláveis, exibindo no máximo três cards por vez e respeitando seus limites visuais.

## v4.3 — Atualização segura da Minha Carteira

Esta versão mantém a estrutura existente e concentra as alterações na experiência e lógica da Minha Carteira:

- Seletor de classe do investimento totalmente clicável, sem tremor e retornando diretamente ao formulário de cadastro.
- Quantidade obrigatória somente para Ações, FIIs, ETFs e BDRs; classes baseadas em valor aceitam valor aplicado e calculam frações quando houver cotação histórica disponível.
- Calendário de compra e venda dentro do layout do próprio aplicativo.
- Histórico de navegação respeitando o caminho real percorrido, inclusive no botão voltar do Android e em grupos da análise.
- Evolução dos investimentos renderizada imediatamente com dados locais antes da atualização pública, evitando tela vazia ao abrir.
- Gráficos de evolução usando dados históricos disponíveis por mês.
- Gráficos de pizza e textos com contenção, dimensionamento responsivo e glow mais próximo do gráfico, sem invadir textos ou sair do card.
- As quatro análises (classe, ativo, setor e instituição) mantêm conteúdos específicos e navegação por grupo.
- A visão detalhada aberta pelo gráfico principal não repete os quatro atalhos de distribuição do dashboard.
- Indicadores separados para Investido, Retorno, Rendimentos, Realizado e Sacado.
- Registro de saques separado de vendas/resultado realizado.
- Cálculo do patrimônio considerando posições atuais e caixa decorrente de vendas/rendimentos registrados, descontando saques registrados.
- Correção do custo investido de ativos de mercado quando o valor investido não foi informado, buscando histórico na fonte pública disponível.
- Animação do botão de atualização de mercado preservada e integrada ao fluxo de atualização.


## v4.10 — Carteira: atualização segura e navegação
- Cadastro de investimentos passa a registrar automaticamente o dia atual, sem seleção manual de data e sem cadastro de vendas.
- Removida a utilização de histórico retroativo para evolução e proventos; dados anteriores ao cadastro são ignorados.
- Proventos de mercado permanecem disponíveis somente a partir da data de cadastro.
- Atualização automática da carteira a cada 1 minuto enquanto o aplicativo está visível, sem aviso/toast para as atualizações automáticas; atualização manual permanece disponível.
- Autocomplete no cadastro de ativo e pesquisa na Evolução dos investimentos, com sugestões a partir de uma letra.
- Evolução mostra inicialmente um ativo por classe presente e permite localizar qualquer ativo pela pesquisa.
- Renda fixa atrelada a indexador possui tipo de rendimento e percentual, com entrada 100 representando 100%.
- Cripto usa o valor aplicado para calcular a posição pela cotação atual quando necessário.
- Cards de detalhamento mantêm espaçamento e são clicáveis por classe, ativo, setor e instituição.
- Navegação Voltar retorna pelo histórico real de telas dentro da carteira.
- Proventos usam máscara/degradê suave nas bordas da área rolável.
- Glow dos gráficos de carteira permanece suave, pulsante e sem caixas internas.


Pacote v4.51: base v4.47 com atualizações de cadastro, instituição/corretora, foco, teclado e cotação de FIIs/ETFs/BDRs.
