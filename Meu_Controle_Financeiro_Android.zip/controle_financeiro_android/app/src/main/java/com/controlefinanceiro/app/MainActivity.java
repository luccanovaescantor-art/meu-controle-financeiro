package com.controlefinanceiro.app;

import android.app.Activity;
import android.os.Build;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER = 4101;
    private static final int CREATE_BACKUP = 4102;
    private String pendingBackup;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final BroadcastReceiver audioReceiver = new BroadcastReceiver(){ @Override public void onReceive(Context c, Intent i){ if(AudioPlaybackService.ACTION_DONE.equals(i.getAction())) webView.evaluateJavascript("window.audioBookNativeEnded && window.audioBookNativeEnded()", null); else if(AudioPlaybackService.ACTION_PROGRESS.equals(i.getAction())) { int pos=i.getIntExtra("position",0), len=i.getIntExtra("length",0); webView.evaluateJavascript("window.audioBookNativeProgress && window.audioBookNativeProgress("+pos+","+len+")", null); } }};

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9001);
        android.content.IntentFilter af=new android.content.IntentFilter(); af.addAction(AudioPlaybackService.ACTION_DONE); af.addAction(AudioPlaybackService.ACTION_PROGRESS); if(Build.VERSION.SDK_INT>=33) registerReceiver(audioReceiver,af, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(audioReceiver,af);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, FILE_CHOOSER);
                return true;
            }
        });
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                try { tts.setLanguage(new Locale("pt", "BR")); } catch (Exception ignored) {}
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) {
                        runOnUiThread(() -> webView.evaluateJavascript("window.audioBookNativeEnded && window.audioBookNativeEnded()", null));
                    }
                    @Override public void onError(String utteranceId) {
                        runOnUiThread(() -> webView.evaluateJavascript("window.audioBookNativeError && window.audioBookNativeError()", null));
                    }
                });
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface public boolean hasNativeTts() { return ttsReady; }

        @JavascriptInterface public String getTtsVoices() {
            if (!ttsReady || tts == null) return "[]";
            try {
            StringBuilder out = new StringBuilder("[");
            boolean first = true;
            java.util.Set<android.speech.tts.Voice> voices=tts.getVoices();
            if(voices==null) return "[]";
            for (android.speech.tts.Voice v : voices) {
                if(v==null) continue;
                Locale l = v.getLocale();
                if (l == null || !"pt".equalsIgnoreCase(l.getLanguage())) continue;
                if (!first) out.append(',');
                first = false;
                String name = v.getName().replace("\\", "\\\\").replace("\"", "\\\"");
                out.append("{\"name\":\"").append(name).append("\",\"lang\":\"").append(l.toLanguageTag()).append("\"}");
            }
            return out.append(']').toString();
            } catch(Exception e){ return "[]"; }
        }

        @JavascriptInterface public boolean ttsSpeak(String text, String voiceName, float rate, float pitch, String title, int position) {
            if (!ttsReady) return false;
            try {
                Intent i=new Intent(MainActivity.this,AudioPlaybackService.class).setAction(AudioPlaybackService.ACTION_SPEAK);
                i.putExtra(AudioPlaybackService.EXTRA_TEXT,text==null?"":text); i.putExtra(AudioPlaybackService.EXTRA_VOICE,voiceName==null?"":voiceName); i.putExtra(AudioPlaybackService.EXTRA_RATE,rate); i.putExtra(AudioPlaybackService.EXTRA_PITCH,pitch); i.putExtra(AudioPlaybackService.EXTRA_TITLE,title==null?"Ensinamento — Meu Controle Financeiro":title); i.putExtra(AudioPlaybackService.EXTRA_POSITION,Math.max(0,position));
                try { if(tts!=null) tts.stop(); } catch(Exception ignored) {}
                if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); return true;
            } catch(Exception e){ return false; }
        }

        @JavascriptInterface public void ttsStop() { Intent i=new Intent(MainActivity.this,AudioPlaybackService.class).setAction(AudioPlaybackService.ACTION_STOP); startService(i); }
        @JavascriptInterface public void ttsPause(){ Intent i=new Intent(MainActivity.this,AudioPlaybackService.class).setAction(AudioPlaybackService.ACTION_PAUSE); startService(i); }
        @JavascriptInterface public void ttsSeek(int position){ Intent i=new Intent(MainActivity.this,AudioPlaybackService.class).setAction(AudioPlaybackService.ACTION_SEEK); i.putExtra(AudioPlaybackService.EXTRA_POSITION,position); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }

        @JavascriptInterface public void saveBackup(String json) {
            pendingBackup = json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "MeuControleFinanceiro_Backup.json");
                startActivityForResult(intent, CREATE_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        } else if (requestCode == CREATE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write((pendingBackup == null ? "" : pendingBackup).getBytes(StandardCharsets.UTF_8));
                }
                webView.evaluateJavascript("toast('Backup salvo com sucesso.')", null);
            } catch (Exception e) {
                webView.evaluateJavascript("toast('Não foi possível salvar o backup.')", null);
            } finally { pendingBackup = null; }
        }
    }

    @Override protected void onDestroy() {
        try{unregisterReceiver(audioReceiver);}catch(Exception ignored){}
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(window.appBack?window.appBack():false)", value -> {
                if ("false".equals(value) || "null".equals(value)) finish();
            });
        } else super.onBackPressed();
    }
}
