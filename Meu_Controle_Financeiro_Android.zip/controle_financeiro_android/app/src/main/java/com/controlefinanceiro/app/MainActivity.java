package com.controlefinanceiro.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER = 4101;
    private static final int CREATE_BACKUP = 4102;
    private String pendingBackup;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, FILE_CHOOSER);
                return true;
            }
        });
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) {
                        runOnUiThread(() -> webView.evaluateJavascript("window.audioBookNativeEnded && window.audioBookNativeEnded()", null));
                    }
                    @Override public void onError(String utteranceId) {
                        runOnUiThread(() -> webView.evaluateJavascript("window.audioBookNativeError && window.audioBookNativeError()", null));
                    }
                });
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class AndroidBridge {
        @JavascriptInterface public boolean hasNativeTts() { return ttsReady; }

        @JavascriptInterface public String getTtsVoices() {
            if (!ttsReady || tts == null) return "[]";
            StringBuilder out = new StringBuilder("[");
            boolean first = true;
            for (android.speech.tts.Voice v : tts.getVoices()) {
                Locale l = v.getLocale();
                if (l == null || !"pt".equalsIgnoreCase(l.getLanguage())) continue;
                if (!first) out.append(',');
                first = false;
                String name = v.getName().replace("\\", "\\\\").replace("\"", "\\\"");
                out.append("{\"name\":\"").append(name).append("\",\"lang\":\"").append(l.toLanguageTag()).append("\"}");
            }
            return out.append(']').toString();
        }

        @JavascriptInterface public boolean ttsSpeak(String text, String voiceName, float rate, float pitch) {
            if (!ttsReady || tts == null) return false;
            try {
                if (voiceName != null && !voiceName.isEmpty()) {
                    for (android.speech.tts.Voice v : tts.getVoices()) {
                        if (voiceName.equals(v.getName())) { tts.setVoice(v); break; }
                    }
                } else tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(Math.max(0.1f, Math.min(3f, rate)));
                tts.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
                tts.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "mcf_audio");
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void ttsStop() { if (tts != null) tts.stop(); }

        @JavascriptInterface public void saveBackup(String json) {
            pendingBackup = json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "MeuControleFinanceiro_Backup.json");
                startActivityForResult(intent, CREATE_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        } else if (requestCode == CREATE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write((pendingBackup == null ? "" : pendingBackup).getBytes(StandardCharsets.UTF_8));
                }
                webView.evaluateJavascript("toast('Backup salvo com sucesso.')", null);
            } catch (Exception e) {
                webView.evaluateJavascript("toast('Não foi possível salvar o backup.')", null);
            } finally { pendingBackup = null; }
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(window.appBack?window.appBack():false)", value -> {
                if ("false".equals(value) || "null".equals(value)) finish();
            });
        } else super.onBackPressed();
    }
}
