package com.controlefinanceiro.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public final class NotificationScheduler {
    private static final String PREF="mcf_notifications";
    private static final String KEY="schedule";
    private static final String CHANNEL="mcf_due_dates";
    private static final int BASE=71000;
    private NotificationScheduler(){}
    public static void sync(Context c,String json){
        cancelAll(c);
        try{
            JSONArray a=new JSONArray(json==null?"[]":json);
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply();
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if(am==null)return;
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                long when=o.optLong("at",0); if(when<=System.currentTimeMillis())continue;
                Intent in=new Intent(c,DueNotificationReceiver.class).setAction("com.controlefinanceiro.app.DUE");
                in.putExtra("id",o.optString("id","")); in.putExtra("title",o.optString("title","Lembrete financeiro")); in.putExtra("text",o.optString("text","")); in.putExtra("count",o.optInt("count",1));
                int req=BASE+Math.abs(o.optString("id",String.valueOf(i)).hashCode()%100000);
                PendingIntent pi=PendingIntent.getBroadcast(c,req,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.set(AlarmManager.RTC_WAKEUP,when,pi);
            }
        }catch(Exception ignored){}
    }
    public static void cancelAll(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); if(am==null)return;
        String old=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]");
        try{JSONArray a=new JSONArray(old);for(int i=0;i<a.length();i++){String id=a.getJSONObject(i).optString("id",String.valueOf(i));Intent in=new Intent(c,DueNotificationReceiver.class).setAction("com.controlefinanceiro.app.DUE");int req=BASE+Math.abs(id.hashCode()%100000);PendingIntent pi=PendingIntent.getBroadcast(c,req,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);pi.cancel();}}catch(Exception ignored){}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    public static void clearShown(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
        String old=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]");
        try{JSONArray a=new JSONArray(old);for(int i=0;i<a.length();i++){String id=a.getJSONObject(i).optString("id",String.valueOf(i));nm.cancel(Math.abs(id.hashCode()));}}catch(Exception ignored){}
    }
    public static void createChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"Vencimentos e lembretes",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Lembretes de contas e dívidas com vencimento");ch.setShowBadge(true);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
    }
    static Notification buildNotification(Context c,String title,String text,int count){
        createChannel(c);Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pi=PendingIntent.getActivity(c,79001,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setOnlyAlertOnce(true).setNumber(Math.max(1,count)).setContentIntent(pi);return b.build();
    }
    public static class DueNotificationReceiver extends BroadcastReceiver{
        @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");String title=i.getStringExtra("title");String text=i.getStringExtra("text");int count=i.getIntExtra("count",1);NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(Math.abs((id==null?String.valueOf(System.currentTimeMillis()):id).hashCode()),buildNotification(c,title,text,count));}
    }
    public static class BootReceiver extends BroadcastReceiver{
        @Override public void onReceive(Context c,Intent i){if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){String s=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]");sync(c,s);}}
    }
}
