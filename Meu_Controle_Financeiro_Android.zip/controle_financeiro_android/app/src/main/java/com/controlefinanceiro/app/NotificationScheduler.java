package com.controlefinanceiro.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.*;
import java.text.*;
import java.util.*;

public final class NotificationScheduler {
    static final String PREFS="cf_notifications";
    static final String DATA="data";
    static final String CHANNEL="cf_due_dates";
    static final int BASE=7400;
    private NotificationScheduler(){}
    static void ensureChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Vencimentos",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Lembretes de vencimentos e atrasos");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    static void sync(Context c,String json){
        try{
            c.getSharedPreferences(PREFS,0).edit().putString(DATA,json).apply();
            ensureChannel(c);
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            for(int i=0;i<500;i++) am.cancel(pi(c,BASE+i,null));
            JSONObject root=new JSONObject(json); JSONArray debts=root.optJSONArray("debts"); if(debts==null)return;
            int slot=0; Date now=new Date();
            for(int i=0;i<debts.length();i++){
                JSONObject d=debts.optJSONObject(i); if(d==null)continue;
                String type=d.optString("type","");
                if("installment".equals(type)){
                    JSONArray paid=d.optJSONArray("paid"); int total=Math.max(1,d.optInt("total",1)); int next=0;
                    for(int n=1;n<=total;n++){boolean p=false;if(paid!=null)for(int k=0;k<paid.length();k++)if(paid.optInt(k)==n){p=true;break;}if(!p){next=n;break;}}
                    if(next>0)slot=scheduleSeries(c,am,d,slot,installmentDue(d,next),next,now);
                }else if("fixed".equals(type)){
                    int dueDay=d.optInt("due",0); if(dueDay>0){ if(!paidThisMonth(d,"fixed")) slot=scheduleSeries(c,am,d,slot,nextMonthly(dueDay),0,now); else { Calendar cnext=Calendar.getInstance(); cnext.add(Calendar.MONTH,1); cnext.set(Calendar.DAY_OF_MONTH,Math.min(28,Math.max(1,dueDay))); slot=scheduleSeries(c,am,d,slot,cnext.getTime(),0,now); } }
                }else if("interest".equals(type)){
                    int dueDay=d.optInt("due",0); if(dueDay>0){ if(!paidThisMonth(d,"interest")) slot=scheduleSeries(c,am,d,slot,nextMonthly(dueDay),0,now); else { Calendar cnext=Calendar.getInstance(); cnext.add(Calendar.MONTH,1); cnext.set(Calendar.DAY_OF_MONTH,Math.min(28,Math.max(1,dueDay))); slot=scheduleSeries(c,am,d,slot,cnext.getTime(),0,now); } }
                }
                if(slot>=490)break;
            }
            scheduleNextDay(c);
        }catch(Exception ignored){}
    }
    private static int scheduleSeries(Context c,AlarmManager am,JSONObject d,int slot,Date due,int installment,Date now){
        long day=86400000L; int[] offsets={7,5,3,1,0,-1,-3,-5,-7}; String name=d.optString("name","Conta");
        for(int off:offsets){
            long target=due.getTime()-off*day; Calendar cal=Calendar.getInstance();cal.setTimeInMillis(target);cal.set(Calendar.HOUR_OF_DAY,8);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
            if(cal.getTimeInMillis()<=now.getTime())continue;
            String kind=off>0?"soon":off==0?"today":"overdue";
            String title=off>0?"Vencimento próximo":off==0?"Vence hoje":"Conta vencida";
            Intent i=new Intent(c,NotificationReceiver.class);i.putExtra("title",title);i.putExtra("message",message(name,off));i.putExtra("debtId",d.optLong("id",0));i.putExtra("installment",installment);i.putExtra("kind",kind);
            am.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi(c,BASE+slot,i)); slot++; if(slot>=490)break;
        }
        return slot;
    }
    private static String message(String name,int off){if(off>0)return "Faltam "+off+" dias para o vencimento de "+name+".";if(off==0)return name+" vence hoje. Não se esqueça de realizar o pagamento.";int n=-off;if(n==1)return name+" venceu ontem. Você conseguiu realizar o pagamento?";if(n==3)return name+" está vencida há 3 dias. Verifique o pagamento.";if(n==5)return name+" está vencida há 5 dias. Atenção a possíveis juros e multas.";return name+" está vencida há 7 dias. Organize o pagamento para evitar maiores encargos.";}
    private static boolean paidThisMonth(JSONObject d,String kind){try{JSONArray h=d.optJSONArray("history");if(h==null)return false;Calendar now=Calendar.getInstance();String ym=String.format(Locale.US,"%04d-%02d",now.get(Calendar.YEAR),now.get(Calendar.MONTH)+1);for(int i=0;i<h.length();i++){JSONObject x=h.optJSONObject(i);if(x==null)continue;String k=x.optString("kind","");if(!kind.equals(k))continue;String date=x.optString("date","");if(date.matches("\\d{2}/\\d{2}/\\d{4}")){String[] a=date.split("/");if((a[2]+"-"+a[1]).equals(ym))return true;} }return false;}catch(Exception e){return false;}}

    private static Date installmentDue(JSONObject d,int n){try{Calendar c=Calendar.getInstance();String start=d.optString("start","");if(!start.isEmpty()){Date x=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(start);c.setTime(x);}else c.set(Calendar.DAY_OF_MONTH,Math.min(28,Math.max(1,d.optInt("due",10))));c.add(Calendar.MONTH,n-1);return end(c);}catch(Exception e){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,Math.min(28,Math.max(1,d.optInt("due",10))));c.add(Calendar.MONTH,n-1);return end(c);}}
    private static Date nextMonthly(int day){Calendar c=Calendar.getInstance();int d=Math.min(28,Math.max(1,day));c.set(Calendar.DAY_OF_MONTH,d);if(c.getTimeInMillis()<System.currentTimeMillis()){c.add(Calendar.MONTH,1);c.set(Calendar.DAY_OF_MONTH,d);}return end(c);}
    private static Date end(Calendar c){c.set(Calendar.HOUR_OF_DAY,23);c.set(Calendar.MINUTE,59);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTime();}
    static PendingIntent pi(Context c,int request,Intent i){return PendingIntent.getBroadcast(c,request,i==null?new Intent(c,NotificationReceiver.class):i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void scheduleNextDay(Context c){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Calendar n=Calendar.getInstance();n.add(Calendar.DAY_OF_YEAR,1);n.set(Calendar.HOUR_OF_DAY,8);n.set(Calendar.MINUTE,0);n.set(Calendar.SECOND,5);n.set(Calendar.MILLISECOND,0);Intent i=new Intent(c,NotificationReceiver.class).setAction(NotificationReceiver.ACTION_DAILY);am.set(AlarmManager.RTC_WAKEUP,n.getTimeInMillis(),PendingIntent.getBroadcast(c,7399,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));}
}
