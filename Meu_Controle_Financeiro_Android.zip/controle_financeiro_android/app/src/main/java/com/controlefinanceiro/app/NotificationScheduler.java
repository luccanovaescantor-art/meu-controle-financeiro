package com.controlefinanceiro.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class NotificationScheduler {
    static final String PREFS="mcf_notifications";
    static final String JSON="data_json";
    static final String CHANNEL="mcf_due_dates";
    static final int ALARM_ID=7108;
    static final int SUMMARY_ID=7199;
    static final String GROUP="mcf_due_group";

    private NotificationScheduler() {}

    static void ensureChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Vencimentos",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Lembretes de vencimentos e pendências do Meu Controle Financeiro");
            ch.setShowBadge(true);
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    static void schedule(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,NotificationReceiver.class).setAction("com.controlefinanceiro.app.NOTIFY_ALARM");
        PendingIntent pi=PendingIntent.getBroadcast(c,ALARM_ID,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar next=Calendar.getInstance(); next.set(Calendar.HOUR_OF_DAY,8); next.set(Calendar.MINUTE,0); next.set(Calendar.SECOND,0); next.set(Calendar.MILLISECOND,0);
        if(!next.after(Calendar.getInstance())) next.add(Calendar.DAY_OF_YEAR,1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),pi);
    }

    static void sync(Context c,String json){
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(JSON,json==null?"":json).apply();
        ensureChannel(c); schedule(c);
    }

    static void clear(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(SUMMARY_ID);
        for(int i=0;i<100;i++) nm.cancel(7200+i);
    }

    static void emit(Context c){
        if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
        String json=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(JSON,"");
        if(json.isEmpty())return;
        try{
            JSONObject root=new JSONObject(json);
            JSONArray debts=root.optJSONArray("debts"); if(debts==null)return;
            Calendar today=Calendar.getInstance(); zero(today);
            JSONArray notices=new JSONArray();
            for(int i=0;i<debts.length();i++){
                JSONObject d=debts.optJSONObject(i); if(d==null)continue;
                String type=d.optString("type",""); if("personal".equals(type))continue;
                int diff;
                if("installment".equals(type)){
                    DueInfo info=nextInstallment(d,today); if(info==null||info.complete)continue; diff=daysBetween(today,info.due);
                }else if("fixed".equals(type)||"interest".equals(type)){
                    int due=d.optInt("due",0); if(due<=0)continue;
                    Calendar dueDate=(Calendar)today.clone(); dueDate.set(Calendar.DAY_OF_MONTH,Math.min(due,dueDate.getActualMaximum(Calendar.DAY_OF_MONTH));
                    diff=daysBetween(today,dueDate);
                    if(diff < -7){dueDate.add(Calendar.MONTH,1);dueDate.set(Calendar.DAY_OF_MONTH,Math.min(due,dueDate.getActualMaximum(Calendar.DAY_OF_MONTH)));diff=daysBetween(today,dueDate);}
                    if("fixed".equals(type) && paidThisMonth(d,"fixed",today))continue;
                    if("interest".equals(type) && (d.optDouble("principal",0)<=0 || paidThisMonth(d,"interest",today)))continue;
                }else continue;
                if(!isOffset(diff))continue;
                String name=d.optString("name","Conta");
                String text=diff>0?"Vence em "+diff+" dia"+(diff==1?"":"s")+": "+name:(diff==0?name+" vence hoje":name+" está vencida há "+Math.abs(diff)+" dia"+(Math.abs(diff)==1?"":"s"));
                JSONObject n=new JSONObject(); n.put("id",d.optLong("id",i)+":"+diff); n.put("name",name); n.put("text",text); notices.put(n);
            }
            NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(SUMMARY_ID);
            if(notices.length()==0)return;
            Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent content=PendingIntent.getActivity(c,7000,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            for(int i=0;i<notices.length();i++){
                JSONObject n=notices.getJSONObject(i);
                Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
                b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Meu Controle Financeiro").setContentText(n.getString("text"))
                 .setStyle(new Notification.BigTextStyle().bigText(n.getString("text"))).setContentIntent(content).setAutoCancel(true)
                 .setGroup(GROUP).setNumber(notices.length()).setOnlyAlertOnce(true);
                nm.notify(7200+i,b.build());
            }
            Notification.Builder summary=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
            summary.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Meu Controle Financeiro")
                   .setContentText(notices.length()+" lembrete"+(notices.length()==1?"":"s")+" de vencimento")
                   .setGroup(GROUP).setGroupSummary(true).setNumber(notices.length()).setContentIntent(content).setAutoCancel(true);
            nm.notify(SUMMARY_ID,summary.build());
        }catch(Exception ignored){}
    }

    static boolean isOffset(int d){return d==7||d==5||d==3||d==1||d==0||d==-1||d==-3||d==-5||d==-7;}
    static void zero(Calendar c){c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);}
    static int daysBetween(Calendar a,Calendar b){long diff=b.getTimeInMillis()-a.getTimeInMillis();return (int)Math.round(diff/86400000.0);}
    static boolean paidThisMonth(JSONObject d,String kind,Calendar today){JSONArray h=d.optJSONArray("history");if(h==null)return false;for(int i=0;i<h.length();i++){JSONObject x=h.optJSONObject(i);if(x==null||!kind.equals(x.optString("kind")))continue;long ts=x.optLong("ts",0);if(ts>0){Calendar c=Calendar.getInstance();c.setTimeInMillis(ts);if(c.get(Calendar.YEAR)==today.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==today.get(Calendar.MONTH))return true;}}return false;}
    static Date parseDate(String s){try{return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s);}catch(ParseException e){return null;}}
    static DueInfo nextInstallment(JSONObject d,Calendar today){
        JSONArray paid=d.optJSONArray("paid"); int total=Math.max(1,d.optInt("total",1)); int next=0;
        for(int i=1;i<=total;i++){boolean isPaid=false;if(paid!=null)for(int j=0;j<paid.length();j++)if(paid.optInt(j)==i){isPaid=true;break;}if(!isPaid){next=i;break;}}
        if(next==0)return new DueInfo(null,true);
        Calendar due=Calendar.getInstance(); String start=d.optString("start",""); Date sd=parseDate(start); if(sd!=null){due.setTime(sd);due.add(Calendar.MONTH,next-1);}else{due.setTimeInMillis(today.getTimeInMillis());due.add(Calendar.MONTH,next-1);due.set(Calendar.DAY_OF_MONTH,Math.min(28,Math.max(1,d.optInt("due",1))));}
        zero(due);return new DueInfo(due,false);
    }
    static class DueInfo{Calendar due;boolean complete;DueInfo(Calendar d,boolean c){due=d;complete=c;}}
}
