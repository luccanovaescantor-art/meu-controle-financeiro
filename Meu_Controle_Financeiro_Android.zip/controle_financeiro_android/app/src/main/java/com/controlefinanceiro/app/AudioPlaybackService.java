package com.controlefinanceiro.app;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class AudioPlaybackService extends Service {
    public static final String ACTION_SPEAK="com.controlefinanceiro.app.SPEAK";
    public static final String ACTION_PAUSE="com.controlefinanceiro.app.PAUSE";
    public static final String ACTION_PLAY="com.controlefinanceiro.app.PLAY";
    public static final String ACTION_SEEK="com.controlefinanceiro.app.SEEK";
    public static final String ACTION_STOP="com.controlefinanceiro.app.STOP";
    public static final String ACTION_NOTIFY="com.controlefinanceiro.app.NOTIFY";
    public static final String ACTION_DONE="com.controlefinanceiro.app.AUDIO_DONE";
    public static final String ACTION_PROGRESS="com.controlefinanceiro.app.AUDIO_PROGRESS";
    public static final String EXTRA_TEXT="text", EXTRA_VOICE="voice", EXTRA_RATE="rate", EXTRA_PITCH="pitch", EXTRA_TITLE="title", EXTRA_POSITION="position";
    private static final String CHANNEL="mcf_audio";
    private static final String DUE_CHANNEL="mcf_due";
    private TextToSpeech tts;
    private MediaSession mediaSession;
    private String currentText="", voiceName="", title="Meu Controle Financeiro";
    private float rate=1f,pitch=1f;
    private boolean ready=false, paused=false;
    private int currentPosition=0;
    private Intent pendingSpeakIntent=null;
    private int spokenStart=0;

    @Override public void onCreate(){ super.onCreate();
        createChannel();
        try { startForeground(11,notification(false)); } catch(Exception ignored) {}
        mediaSession=new MediaSession(this,"MeuControleFinanceiroAudio");
        mediaSession.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){ speakCurrent(); }
            @Override public void onPause(){ pauseCurrent(); }
            @Override public void onStop(){ stopCurrent(true); }
        });
        tts=new TextToSpeech(this,status->{
            ready=status==TextToSpeech.SUCCESS;
            if(ready){
                try { tts.setLanguage(new Locale("pt","BR")); } catch(Exception ignored) {}
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){ updateMedia(true); }
                    @Override public void onRangeStart(String utteranceId, int start, int end, int frame) {
                        currentPosition = spokenStart + start;
                        sendProgress();
                    }
                    @Override public void onDone(String id){
                        currentPosition = currentText == null ? 0 : currentText.length();
                        sendProgress();
                        paused=false;
                        sendBroadcast(new Intent(ACTION_DONE).setPackage(getPackageName()));
                        stopCurrent(false);
                    }
                    @Override public void onError(String id){
                        sendBroadcast(new Intent(ACTION_DONE).setPackage(getPackageName()));
                        updateMedia(false);
                    }
                });
                if(pendingSpeakIntent!=null){
                    currentText=pendingSpeakIntent.getStringExtra(EXTRA_TEXT);
                    voiceName=pendingSpeakIntent.getStringExtra(EXTRA_VOICE);
                    rate=pendingSpeakIntent.getFloatExtra(EXTRA_RATE,1f);
                    pitch=pendingSpeakIntent.getFloatExtra(EXTRA_PITCH,1f);
                    title=pendingSpeakIntent.getStringExtra(EXTRA_TITLE);
                    currentPosition=Math.max(0,pendingSpeakIntent.getIntExtra(EXTRA_POSITION,0));
                    pendingSpeakIntent=null;
                    speakCurrent();
                }
            }
        });
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null){String a=i.getAction();
            if(ACTION_SPEAK.equals(a)){
                currentText=i.getStringExtra(EXTRA_TEXT);
                voiceName=i.getStringExtra(EXTRA_VOICE);
                rate=i.getFloatExtra(EXTRA_RATE,1f);
                pitch=i.getFloatExtra(EXTRA_PITCH,1f);
                title=i.getStringExtra(EXTRA_TITLE);
                currentPosition=Math.max(0,i.getIntExtra(EXTRA_POSITION,0));
                paused=false;
                pendingSpeakIntent=new Intent(i);
                speakCurrent();
            }
            else if(ACTION_NOTIFY.equals(a)) showDueNotification(i);
            else if(ACTION_PAUSE.equals(a)) pauseCurrent();
            else if(ACTION_PLAY.equals(a)) speakCurrent();
            else if(ACTION_SEEK.equals(a)) seekCurrent(i.getIntExtra(EXTRA_POSITION,0));
            else if(ACTION_STOP.equals(a)) stopCurrent(true);
        }
        return START_STICKY;
    }
    private void speakCurrent(){
        if(!ready||tts==null||currentText==null||currentText.isEmpty()) return;
        try{
            if(voiceName!=null&&!voiceName.isEmpty()) {
                for(android.speech.tts.Voice v:tts.getVoices()) if(voiceName.equals(v.getName())){tts.setVoice(v);break;}
            } else { tts.setLanguage(new Locale("pt","BR")); }
            tts.setSpeechRate(Math.max(.1f,Math.min(3f,rate)));
            tts.setPitch(Math.max(.5f,Math.min(2f,pitch)));
            int pos=Math.max(0,Math.min(currentPosition,currentText.length()));
            spokenStart=pos;
            String toSpeak=currentText.substring(pos);
            if(toSpeak.trim().isEmpty()){ currentPosition=currentText.length(); sendProgress(); return; }
            tts.speak(toSpeak,TextToSpeech.QUEUE_FLUSH,null,"mcf_audio");
            paused=false; updateMedia(true); sendProgress();
        }catch(Exception ignored){}
    }
    private void pauseCurrent(){ if(tts!=null){tts.stop();paused=true;updateMedia(false);sendProgress();} }
    private void seekCurrent(int position){
        if(currentText==null||currentText.isEmpty()) return;
        currentPosition=Math.max(0,Math.min(position,currentText.length()));
        if(ready) speakCurrent(); else sendProgress();
    }
    private void sendProgress(){
        Intent p=new Intent(ACTION_PROGRESS).setPackage(getPackageName());
        p.putExtra("position",currentPosition);
        p.putExtra("length",currentText==null?0:currentText.length());
        sendBroadcast(p);
    }
    private void stopCurrent(boolean end){ if(tts!=null)tts.stop();paused=false;currentPosition=0;if(end) {currentText="";title="Meu Controle Financeiro";} updateMedia(false);sendProgress(); if(end) stopForeground(STOP_FOREGROUND_REMOVE); if(end) stopSelf(); }
    private void updateMedia(boolean playing){ if(mediaSession==null)return; long actions=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_STOP; int state=playing?PlaybackState.STATE_PLAYING:(paused?PlaybackState.STATE_PAUSED:PlaybackState.STATE_STOPPED); mediaSession.setPlaybackState(new PlaybackState.Builder().setActions(actions).setState(state,PlaybackState.PLAYBACK_POSITION_UNKNOWN,1f).build()); mediaSession.setActive(playing||paused); if(playing||paused) startForeground(11,notification(playing)); else stopForeground(STOP_FOREGROUND_REMOVE); }
    private Notification notification(boolean playing){
        Intent pause=new Intent(this,AudioPlaybackService.class).setAction(playing?ACTION_PAUSE:ACTION_PLAY); PendingIntent pp=PendingIntent.getService(this,20,pause,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,AudioPlaybackService.class).setAction(ACTION_STOP); PendingIntent sp=PendingIntent.getService(this,21,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(com.controlefinanceiro.app.R.mipmap.ic_launcher).setContentTitle(title==null||title.isEmpty()?"Meu Controle Financeiro":title).setContentText(playing?"Lendo ensinamento":"Leitura pausada").setOngoing(playing||paused).setOnlyAlertOnce(true).addAction(new Notification.Action.Builder(null,playing?"Pausar":"Reproduzir",pp).build()).addAction(new Notification.Action.Builder(null,"Parar",sp).build());
        return b.build();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel c=new NotificationChannel(CHANNEL,"Leitura dos ensinamentos",NotificationManager.IMPORTANCE_LOW);c.setDescription("Controles de áudio do Meu Controle Financeiro");nm.createNotificationChannel(c);NotificationChannel d=new NotificationChannel(DUE_CHANNEL,"Vencimentos e pendências",NotificationManager.IMPORTANCE_DEFAULT);d.setDescription("Avisos de vencimentos próximos e vencidos");d.enableVibration(true);nm.createNotificationChannel(d);}}
    private void showDueNotification(Intent i){String name=i.getStringExtra("notify_name");int off=i.getIntExtra("notify_offset",0),id=i.getIntExtra("notify_id",(name==null?"Conta":name).hashCode()),count=i.getIntExtra("notify_count",1);if(name==null||name.isEmpty())name="Conta";String text=off>0?"Vence em "+off+" dia"+(off==1?"":"s"):off==0?"Vence hoje":"Está vencida há "+Math.abs(off)+" dia"+(Math.abs(off)==1?"":"s");Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,DUE_CHANNEL):new Notification.Builder(this);b.setSmallIcon(com.controlefinanceiro.app.R.mipmap.ic_launcher).setContentTitle(name).setContentText(text).setAutoCancel(true).setOnlyAlertOnce(true).setNumber(Math.max(1,count)).setCategory(Notification.CATEGORY_REMINDER);if(Build.VERSION.SDK_INT>=21)b.setPriority(Notification.PRIORITY_DEFAULT);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.notify(id,b.build());try{stopForeground(STOP_FOREGROUND_REMOVE);}catch(Exception ignored){}stopSelf();}
    @Override public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}if(mediaSession!=null){mediaSession.release();}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
