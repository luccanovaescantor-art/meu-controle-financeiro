package com.controlefinanceiro.app;

import android.app.*;import android.content.*;import android.os.*;import org.json.*;

public class NotificationReceiver extends BroadcastReceiver {
 public static final String ACTION_DAILY="com.controlefinanceiro.app.DAILY";
 @Override public void onReceive(Context c,Intent intent){
  NotificationScheduler.ensureChannel(c);
  if(ACTION_DAILY.equals(intent.getAction())){String json=c.getSharedPreferences(NotificationScheduler.PREFS,0).getString(NotificationScheduler.DATA,"");if(!json.isEmpty())NotificationScheduler.sync(c,json);return;}
  String title=intent.getStringExtra("title"),msg=intent.getStringExtra("message");long debtId=intent.getLongExtra("debtId",0);int installment=intent.getIntExtra("installment",0);String kind=intent.getStringExtra("kind");
  Intent open=new Intent(c,MainActivity.class).setAction("OPEN_DEBT").putExtra("debtId",debtId).putExtra("installment",installment).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pi=PendingIntent.getActivity(c,(int)((debtId%100000)*10+installment),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,NotificationScheduler.CHANNEL):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"Lembrete":title).setContentText(msg==null?"Confira seus pagamentos.":msg).setAutoCancel(true).setContentIntent(pi);int id=(int)((debtId%100000)*10+installment+Math.abs((kind==null?0:kind.hashCode())%7));((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
  try{JSONArray a=new JSONArray(c.getSharedPreferences(NotificationScheduler.PREFS,0).getString("today_items","[]"));JSONObject n=new JSONObject();n.put("title",title);n.put("message",msg);n.put("debtId",debtId);n.put("installment",installment);n.put("kind",kind);n.put("ts",System.currentTimeMillis());a.put(n);c.getSharedPreferences(NotificationScheduler.PREFS,0).edit().putString("today_items",a.toString()).apply();}catch(Exception ignored){}
 }
}
