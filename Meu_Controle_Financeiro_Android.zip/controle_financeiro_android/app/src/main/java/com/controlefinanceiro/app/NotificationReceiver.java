package com.controlefinanceiro.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class NotificationReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent){ NotificationScheduler.ensureChannel(context); NotificationScheduler.emit(context); NotificationScheduler.schedule(context); }
}
