package com.controlefinanceiro.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class NotificationBootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent){ NotificationScheduler.ensureChannel(context); NotificationScheduler.schedule(context); }
}
