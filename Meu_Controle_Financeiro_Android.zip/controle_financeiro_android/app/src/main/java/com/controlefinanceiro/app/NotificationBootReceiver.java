package com.controlefinanceiro.app;
import android.content.*;
public class NotificationBootReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent i){String json=c.getSharedPreferences(NotificationScheduler.PREFS,0).getString(NotificationScheduler.DATA,"");if(!json.isEmpty())NotificationScheduler.sync(c,json);}
}
