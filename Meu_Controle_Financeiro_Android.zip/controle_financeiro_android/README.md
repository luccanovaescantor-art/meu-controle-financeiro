# Meu Controle Financeiro — versão 1.2 refinada

Projeto Android (WebView + HTML/CSS/JS) para o aplicativo pessoal de controle de dívidas e pagamentos.

## Principais correções desta revisão
- Ícone oficial baseado exatamente na arte enviada, com margem interna para evitar cortes no launcher.
- Abertura reconstruída com a mesma carteira e tipografia da identidade oficial, sem cortar a composição final.
- Dashboard com total de dívidas em cor neutra; pago em verde e restante em vermelho.
- Barra inferior com ícones vetoriais personalizados e botão + centralizado.
- Calendário personalizado corrigido e funcional.
- Reordenação do Dashboard por arrastar e soltar com persistência.
- Relatórios alimentados por pagamentos reais, com visão mensal, semanal e anual.
- Histórico de pagamentos com data, hora, parcela, dívida e detalhes.
- Gráficos de pizza reais no Dashboard e nas dívidas.
- Exclusão de dívidas com confirmação.
- Tema escuro/claro e demais configurações preservados.
- Área Aprender com cards clicáveis e conteúdo aprofundado.
- Navegação de voltar integrada ao botão/gesto Back do Android.

## Build
O workflow do GitHub Actions pode usar o Gradle instalado no runner.
Application ID: `com.controlefinanceiro.app`
Version name: `1.2`
