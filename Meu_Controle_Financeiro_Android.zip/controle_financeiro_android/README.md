# Meu Controle Financeiro — versão 1.2 refinada

Projeto Android/WebView do aplicativo pessoal **Meu Controle Financeiro**.

## Identidade
- Ícone oficial baseado na arte fornecida pelo proprietário, com área segura para evitar cortes.
- Splash curta com a composição completa da logo, sem recortes.
- Interface escura premium e tema claro opcional.
- Ícones vetoriais próprios na navegação e na área Aprender.

## Funcionalidades principais
- Dashboard com total de dívidas a quitar, pago/restante e gráficos de pizza.
- Dívidas parceladas, dívidas com juros sobre saldo, dívidas pessoais e custos fixos mensais separados.
- Histórico de pagamentos com data, hora e detalhes.
- Relatórios baseados nos pagamentos reais, por mês, semana e ano.
- Calendário personalizado.
- Exclusão com confirmação.
- Navegação pelo voltar do Android e atalho da saudação para o Dashboard.
- Personalização da ordem do Dashboard por toque prolongado e arrastar/soltar, com persistência.
- Tema escuro/claro, moeda e backup/restauração.
- Área Aprender com conteúdos variados e aba Livros; cada livro possui 30 ensinamentos autorais aprofundados.

## Build
O workflow do GitHub Actions pode usar este projeto para gerar a APK. Este pacote não inclui o Gradle Wrapper; o workflow deve configurar o Gradle no runner.
