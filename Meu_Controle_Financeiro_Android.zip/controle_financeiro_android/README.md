# Meu Controle Financeiro — versão 1.2

Projeto Android para gerar o APK do aplicativo pessoal de controle de dívidas.

- applicationId: com.controlefinanceiro.app
- versionName: 1.2
- versionCode: 13
- Java 17 / Android SDK 35
- Interface em WebView com armazenamento local.

A identidade visual oficial foi incorporada a partir da imagem fornecida pelo usuário. A tela de abertura usa recortes da mesma identidade para a animação curta de entrada.
