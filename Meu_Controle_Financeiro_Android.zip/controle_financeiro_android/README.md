# Meu Controle Financeiro — v1.2

Projeto Android do aplicativo Meu Controle Financeiro.

- applicationId: com.controlefinanceiro.app
- versionCode: 2
- versionName: 1.2
- compileSdk/targetSdk: 35
- JavaScript/WebView com armazenamento local

O app preserva a chave de dados `controle_financeiro_v3` da versão anterior para manter os dados já cadastrados no aparelho.
