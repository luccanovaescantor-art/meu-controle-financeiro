# Meu Controle Financeiro — versão atualizada

Projeto Android/WebView do aplicativo **Meu Controle Financeiro**.

## Principais correções desta versão
- Gráficos de pizza no dashboard e nos detalhes das dívidas.
- Dívidas fixas separadas do total de dívidas a quitar.
- Valor total original exibido no detalhe de dívidas parceladas.
- Exclusão de dívidas funcionando.
- Botão/saudação para retornar ao Dashboard e navegação pelo botão Voltar do Android.
- Reordenação do Dashboard por pressionar e arrastar, com salvamento da ordem.
- Tema claro e escuro.
- Ícones vetoriais personalizados na navegação e no Aprender.
- Calendário personalizado funcional para datas.
- Relatórios baseados nos pagamentos registrados.
- Histórico de pagamentos com data, hora e detalhes.
- Aprender com 20 livros, conteúdos variados por tema e uma aba de Livros.
- 30 ensinamentos aprofundados por livro (600 no total), com contexto, entendimento, ensinamento, aplicação, exemplo, exercício e reflexão.
- Splash screen simples com carteira descendo, nome subindo e luz de estúdio após o encontro, sem recortes.
- Ícone do aplicativo sem textos, usando a carteira como identidade visual.
- Backup completo em JSON, com salvar via seletor do Android e importação validada.

## Build
Abra `controle_financeiro_android` no Android Studio e gere o APK normalmente.
