# Meu Controle Financeiro — versão 2.34

Projeto Android/WebView do aplicativo **Meu Controle Financeiro**.

## Principais correções desta versão
- Ícone externo do aplicativo reconstruído a partir da carteira PNG original, em fundo escuro, com margem segura para evitar recorte no launcher.
- Splash screen refeita com a carteira original descendo de cima para baixo e o nome subindo de baixo para cima, encontrando-se juntos na região central da tela, sem quadrados, cortes ou sobreposição; o nome termina logo abaixo da carteira.
- Dashboard com análise financeira gráfica ao tocar no resumo: pizza de pago/restante/pendente quando houver atraso, barras mensais e diárias, evolução anual e indicadores reais; gráficos e status são atualizados após cada pagamento.
- Dashboard com reordenação por arrastar e também controles de subir/descer como alternativa, com salvamento da ordem.
- Cards de dívida com vencimento na linha superior, espaçamento interno mais confortável e valor total sempre presente junto dos demais indicadores.
- Status das dívidas recalculado automaticamente pela parcela pendente: Em aberto em branco acima de 7 dias; Vencimento próximo em amarelo/laranja de 7 dias até a véspera; Vencida em vermelho após o vencimento; após o pagamento, o card avança imediatamente para a próxima parcela e recalcula o status.
- Botão “Ver todas” e demais cards com espaçamento visual consistente.
- Relatórios com espaçamento corrigido e visão de pagamentos dos últimos 7 dias na análise gráfica.
- Pagamentos como extrato cronológico; cada registro abre um comprovante focado em valor, dívida, parcela, data e horário.
- Formulários de nova dívida e edição preservam todos os campos ao abrir calendário ou seletor e não sobrescrevem histórico existente.
- Calendário personalizado funcional para seleção de datas.
- Aprender com 20 livros e 600 ensinamentos (30 por livro), distribuídos de forma variada por tema.
- Ensinamentos com títulos e textos individualizados por livro e por entrada, com uma única leitura contínua e sem blocos repetitivos de “contexto/exercício/reflexão”.
- Aba Livros preservada, com 30 ensinamentos individualizados dentro de cada obra.
- Ícones personalizados na área de Aprender e na navegação inferior, com os ícones inferiores levemente ampliados sem alterar o botão central.
- Backup completo em JSON, com salvar via seletor do Android e importação validada.
- Animação minimalista de quitação somente quando a última parcela é paga, com artefatos visuais na identidade verde do aplicativo.

## Build
Abra `controle_financeiro_android` no Android Studio e gere o APK normalmente.


## Versão 2.0 — leitura dos ensinamentos
- Audiobook por Text-to-Speech do Android/WebView.
- Escolha da voz em português entre as vozes disponíveis no aparelho.
- Vozes identificadas pelo sistema como femininas/masculinas são sinalizadas.
- Velocidade de 0,5x a 2,0x.
- Tom mais grave, normal ou mais agudo.
- Preferências de voz salvas no dispositivo.
- Reprodução com pausa, retorno e avanço por trechos.

## Ajustes finais — 2.0
- Dashboard principal: resumo das dívidas unificado em um único card, com gráfico de pizza predominante e indicadores laterais.
- “Minhas dívidas” na tela inicial limitada às duas obrigações mais próximas; “Ver todas” mantém somente dívidas não fixas.
- Custos fixos mensais: botão “Ver todos”, lista separada para edição/pagamento e gráfico de pizza com uma cor por custo e percentual de participação no total mensal.
- Análise financeira: total, pago, restante, quitado e pendente reunidos em um único card maior, com pizza predominante; demais gráficos mantidos abaixo.
- Todos os gráficos de barras receberam margem superior para que as barras nunca cubram os valores exibidos no topo.
- Relatórios: gráfico “Evolução dos últimos 6 meses” corrigido para representar proporcionalmente os pagamentos reais registrados, inclusive o mês atual, com margem superior e valores legíveis.
- Espaçamento dos cards de maior/menor mês e demais blocos de análise ajustado para evitar encaixes colados.
- Cards de configurações de voz e Dashboard padronizados com divisor interno e botão em largura completa, seguindo o padrão de Backup e dados.
- Sheets/modais podem ser fechados arrastando para baixo a partir de qualquer área do card, além do gesto pela barra superior.
- Barra do audiobook com altura e interação de arraste corrigidas para permitir busca no texto de forma mais confiável.
- Ensinamentos: cada entrada usa título, abertura e estrutura de resumo próprios, com variação de abordagem entre os 30 tópicos de cada livro e títulos protegidos contra duplicação entre obras.


Versão de correção: v3.0 — ajustes incrementais de navegação, modais, orçamento, metas, campos de valor e saudação.


Base desta entrega: v2.33 — correção incremental sobre a última versão funcional v2.31, preservando as funcionalidades existentes.


## v3.5 — Carteira: análise e dados de mercado
- Dashboard inicial da carteira foi separado da visão analítica completa.
- Clique em Por classe, Por ativo, Por setor e Por instituição abre uma tela própria com gráfico e detalhamento.
- Evolução do patrimônio usa histórico de snapshots para gráfico de linha.
- Clique no investimento abre detalhes do ativo antes da edição.
- Atualização de mercado integrada para cripto via Binance e B3 via brapi, com fallback Stooq.
- A brapi gratuita tem atraso aproximado de 30 minutos para ações; portanto o app não chama isso de tempo real.
- A atualização pode ser manual e também periódica enquanto o app estiver aberto.
- Atalhos/símbolos comuns como Petro4/Petrobras são normalizados para PETR4.
