# Meu Controle Financeiro 1.1

Atualização do aplicativo Android pessoal.

## Alterações desta versão
- Interface predominantemente preta/escura.
- Botões e superfícies em cinza grafite para contraste.
- Verde para informações positivas e pagamentos.
- Vermelho para despesas/pendências negativas.
- Ícone personalizado do aplicativo.
- Correção do cadastro de dívida/conta: os campos agora são lidos explicitamente pelo formulário antes de salvar, evitando conflito com nomes globais do WebView.
- Dívidas continuam separadas do histórico de pagamentos.
- Funciona offline e mantém os dados no armazenamento local do aplicativo.
