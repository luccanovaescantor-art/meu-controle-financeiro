# Meu Controle Financeiro — versão 2.0

Projeto Android/WebView do aplicativo **Meu Controle Financeiro**.

## Principais correções desta versão
- Ícone externo do aplicativo reconstruído a partir da carteira PNG original, em fundo escuro, com margem segura para evitar recorte no launcher.
- Splash screen refeita com a carteira original descendo de cima para baixo e o nome subindo de baixo para cima, encontrando-se juntos na região central da tela, sem quadrados, cortes ou sobreposição; o nome termina logo abaixo da carteira.
- Dashboard com análise financeira gráfica ao tocar no resumo: pizza de pago/restante/pendente quando houver atraso, barras mensais e diárias, evolução anual e indicadores reais; gráficos e status são atualizados após cada pagamento.
- Dashboard com reordenação por arrastar e também controles de subir/descer como alternativa, com salvamento da ordem.
- Cards de dívida com vencimento na linha superior, espaçamento interno mais confortável e valor total sempre presente junto dos demais indicadores.
- Status das dívidas recalculado automaticamente pela parcela pendente: Em aberto em branco acima de 7 dias; Vencimento próximo em amarelo/laranja de 7 dias até a véspera; Vencida em vermelho após o vencimento; após o pagamento, o card avança imediatamente para a próxima parcela e recalcula o status.
- Botão “Ver todas” e demais cards com espaçamento visual consistente.
- Relatórios com espaçamento corrigido e visão de pagamentos dos últimos 7 dias na análise gráfica.
- Pagamentos como extrato cronológico; cada registro abre um comprovante focado em valor, dívida, parcela, data e horário.
- Formulários de nova dívida e edição preservam todos os campos ao abrir calendário ou seletor e não sobrescrevem histórico existente.
- Calendário personalizado funcional para seleção de datas.
- Aprender com 20 livros e 600 ensinamentos (30 por livro), distribuídos de forma variada por tema.
- Ensinamentos com títulos e textos individualizados por livro e por entrada, com uma única leitura contínua e sem blocos repetitivos de “contexto/exercício/reflexão”.
- Aba Livros preservada, com 30 ensinamentos individualizados dentro de cada obra.
- Ícones personalizados na área de Aprender e na navegação inferior, com os ícones inferiores levemente ampliados sem alterar o botão central.
- Backup completo em JSON, com salvar via seletor do Android e importação validada.
- Animação minimalista de quitação somente quando a última parcela é paga, com artefatos visuais na identidade verde do aplicativo.

## Build
Abra `controle_financeiro_android` no Android Studio e gere o APK normalmente.


## Versão 2.0 — leitura dos ensinamentos
- Audiobook por Text-to-Speech do Android/WebView.
- Escolha da voz em português entre as vozes disponíveis no aparelho.
- Vozes identificadas pelo sistema como femininas/masculinas são sinalizadas.
- Velocidade de 0,5x a 2,0x.
- Tom mais grave, normal ou mais agudo.
- Preferências de voz salvas no dispositivo.
- Reprodução com pausa, retorno e avanço por trechos.
