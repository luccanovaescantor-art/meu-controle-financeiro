# Meu Controle Financeiro — Android
O projeto contém a versão Android com WebView e a mesma aplicação web nos assets.

## Como gerar o APK
Abra esta pasta no Android Studio e aguarde a sincronização do Gradle. Depois use:
Build > Build APK(s)
O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk

## Funcionalidades
- Cadastro de dívidas
- Parcelas individuais
- Histórico separado de pagamentos
- Data real do pagamento
- Valor efetivamente pago por parcela
- Dashboard
- Próximos vencimentos
- Backup JSON
- Funcionamento offline
